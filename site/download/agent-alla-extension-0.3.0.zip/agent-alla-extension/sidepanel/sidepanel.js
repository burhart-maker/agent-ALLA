// Agent ALLA side panel — the real chat, talking to the same backend the
// website uses (POST https://agentalla.com/api/chat, which streams an
// Anthropic Messages SSE response back). No API key lives in the
// extension: the key stays server-side in the Cloudflare Pages Function,
// exactly as it does for the site.
//
// MV3 note: extension pages run under `script-src 'self'`, so this file is
// loaded as a module from sidepanel.html rather than inlined.

import { AllaOrb } from "../orb/alla-orb.js";

const API = "https://agentalla.com/api/chat";
const MAX_TURNS = 20;      // trim old exchanges so requests stay light
const STORE_KEY = "allaPanelHistory";

const scrollEl = document.getElementById("scroll");
const inputEl = document.getElementById("input");
const sendBtn = document.getElementById("send");

let history = [];
let busy = false;

// --- brand orb in the header -------------------------------------------
// Asset URLs must be set before the element is created: defining a custom
// element upgrades it on the same tick, so an <alla-orb> written straight
// into the HTML would paint once with the wrong path first.
AllaOrb.spriteUrl = chrome.runtime.getURL("orb/assets/orb-sprite.png");
AllaOrb.plainUrl = chrome.runtime.getURL("orb/assets/header_38.png");
const orb = document.createElement("alla-orb");
orb.setAttribute("size", "26");
orb.setAttribute("state", "idle");
document.getElementById("header").prepend(orb);

// --- rendering ----------------------------------------------------------
function addMessage(role, text, extraClass) {
  const wrap = document.createElement("div");
  wrap.className = "msg " + role + (extraClass ? " " + extraClass : "");
  const who = document.createElement("div");
  who.className = "who";
  who.textContent = role === "user" ? "You" : "Alla";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  wrap.append(who, bubble);
  scrollEl.append(wrap);
  scrollEl.scrollTop = scrollEl.scrollHeight;
  return bubble;
}

function setBusy(state) {
  busy = state;
  sendBtn.disabled = state;
  orb.setAttribute("state", state ? "thinking" : "idle");
}

// --- persistence --------------------------------------------------------
// Keeps the conversation across panel open/close. Local, per-browser; the
// site's own chat history is separate.
async function loadHistory() {
  try {
    const stored = await chrome.storage.local.get(STORE_KEY);
    const saved = stored && stored[STORE_KEY];
    if (Array.isArray(saved) && saved.length) {
      history = saved.slice(-MAX_TURNS * 2);
      history.forEach((m) => addMessage(m.role === "user" ? "user" : "agent", m.content));
      return;
    }
  } catch (e) { /* storage unavailable — start clean */ }
  addMessage("agent", "Hi, I'm Alla — let's pick a property, run the numbers, and compare strategies.");
}

function saveHistory() {
  try {
    chrome.storage.local.set({ [STORE_KEY]: history.slice(-MAX_TURNS * 2) });
  } catch (e) { /* non-fatal */ }
}

// --- network ------------------------------------------------------------
function errorCopy(status) {
  if (status === 429) return "Too many messages just now — give it a moment and try again.";
  if (status === 503) return "Alla is temporarily unavailable. Please try again shortly.";
  if (status === 0) return "No connection. Check your internet and try again.";
  return "Something went wrong reaching Alla. Please try again.";
}

// Parses the Anthropic Messages SSE stream into plain text deltas — the
// same shape the website parses.
async function streamChat(turns, onDelta) {
  let res;
  try {
    res = await fetch(API, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ messages: turns })
    });
  } catch (e) {
    const err = new Error("offline");
    err.status = 0;
    throw err;
  }

  if (!res.ok || !res.body) {
    const err = new Error("chat_failed");
    err.status = res.status;
    throw err;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let full = "";

  for (;;) {
    const chunk = await reader.read();
    if (chunk.done) break;
    buffer += decoder.decode(chunk.value, { stream: true });

    const events = buffer.split("\n\n");
    buffer = events.pop(); // keep the trailing partial event

    for (const raw of events) {
      let dataLine = null;
      for (const line of raw.split("\n")) {
        if (line.indexOf("data:") === 0) dataLine = line.slice(5).trim();
      }
      if (!dataLine || dataLine === "[DONE]") continue;

      let evt;
      try { evt = JSON.parse(dataLine); } catch (e) { continue; }

      if (evt.type === "content_block_delta" && evt.delta && evt.delta.type === "text_delta") {
        full += evt.delta.text;
        onDelta(full);
      }
    }
  }
  return full;
}

// --- send ---------------------------------------------------------------
async function send() {
  const text = inputEl.value.trim();
  if (!text || busy) return;

  inputEl.value = "";
  autoGrow();
  addMessage("user", text);
  history.push({ role: "user", content: text });
  setBusy(true);

  const bubble = addMessage("agent", "Thinking…");
  bubble.classList.add("thinking");

  try {
    const turns = history.slice(-MAX_TURNS * 2);
    const answer = await streamChat(turns, (sofar) => {
      bubble.classList.remove("thinking");
      bubble.textContent = sofar;
      scrollEl.scrollTop = scrollEl.scrollHeight;
    });
    if (answer) {
      history.push({ role: "assistant", content: answer });
    } else {
      bubble.textContent = errorCopy(500);
      bubble.parentElement.classList.add("error");
    }
    saveHistory();
  } catch (err) {
    bubble.classList.remove("thinking");
    bubble.textContent = errorCopy(err && err.status);
    bubble.parentElement.classList.add("error");
    history.pop(); // drop the unanswered turn so it isn't resent as context
  } finally {
    setBusy(false);
    inputEl.focus();
  }
}

function autoGrow() {
  inputEl.style.height = "auto";
  inputEl.style.height = Math.min(inputEl.scrollHeight, 120) + "px";
}

sendBtn.addEventListener("click", send);
inputEl.addEventListener("input", autoGrow);
inputEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    send();
  }
});

loadHistory();
