import { AllaOrb } from "../orb/alla-orb.js";
    AllaOrb.spriteUrl = chrome.runtime.getURL("orb/assets/orb-sprite.png");
    AllaOrb.plainUrl = chrome.runtime.getURL("orb/assets/header_38.png");
    const orb = document.createElement("alla-orb");
    orb.setAttribute("size", "28");
    document.getElementById("heading").prepend(orb);

    const radios = document.querySelectorAll('input[name="mode"]');
    chrome.storage.sync.get(["allaDisplayMode"], (cfg) => {
      const mode = cfg.allaDisplayMode || "always";
      for (const r of radios) r.checked = r.value === mode;
    });
    for (const r of radios) {
      r.addEventListener("change", () => {
        chrome.storage.sync.set({ allaDisplayMode: r.value });
      });
    }
