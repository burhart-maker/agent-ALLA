// Background service worker (MV3). Responsibilities, per the MVP scope in
// agent-alla/browser-extension-orb-visual-audit.md point 25:
//   - toolbar icon click opens the side panel
//   - the floating orb (content script) asks to open the side panel too
//   - per-site display-mode storage lives in chrome.storage.sync (read by
//     both the content script and the options page)
// No page content is read here, no network calls are made — this is pure
// UI plumbing. Talking to Agent Alla's actual backend is a later phase.

chrome.action.onClicked.addListener(async (tab) => {
  if (tab.windowId != null) {
    await chrome.sidePanel.open({ windowId: tab.windowId });
  }
});

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type === "alla:open-side-panel" && sender.tab?.windowId != null) {
    chrome.sidePanel.open({ windowId: sender.tab.windowId });
  }
});

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.storage.sync.set({
      allaDisplayMode: "always", // 'always' | 'never' (default open per <persisted_artifacts>-style safe default; user can restrict from options)
      allaSiteRules: {},
    });
  }
});
