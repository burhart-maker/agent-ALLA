/**
 * Injects the floating Agent ALLA orb into the page.
 *
 * Architecture (per agent-alla/layer-3-saas-architecture.md §10 and
 * agent-alla/browser-extension-orb-visual-audit.md point 10):
 *   Content Script -> one isolated host <div> -> open Shadow DOM -> <alla-orb>
 * so neither the host page's CSS can corrupt the orb, nor the orb's styles
 * leak onto the page. (Shadow mode is "open" rather than "closed": the
 * component itself — orb/alla-orb.classic.js — runs in the page's MAIN
 * world, not this content script's isolated world, because it needs a
 * working `customElements` registry and reads its config from the
 * injected <script>'s own `data-*` attributes/currentScript rather than
 * chrome.* APIs, which aren't available in the main world. "open" lets
 * that main-world code reach the shadow root it just populated; page
 * scripts could technically also reach it, which is an acceptable
 * trade-off for a visual widget with no secrets in it — see the
 * Capability Disclosure Policy §4, "protected internal knowledge" never
 * includes client-side UI like this.) This file only handles: creating
 * the host, injecting the component with the right config, drag-to-
 * reposition + position persistence, and the per-site visibility
 * preference. It does not touch page content, intercept clicks outside
 * its own bounds, or read the page (contextual "Analyze with Alla"
 * property-detection is a later phase, not in this MVP per the audit's
 * point 25 "first implementation target").
 */
(function () {
  if (window.__allaOrbInjected) return;
  window.__allaOrbInjected = true;

  const DEFAULTS = {
    displayMode: "always", // 'always' | 'never' — per-site overrides layered on top, see background/service-worker.js
    positionTopFrac: 0.62, // fraction of viewport height, remembered per-device (not per-site)
    orbSize: 48,
  };

  chrome.storage.sync.get(["allaDisplayMode", "allaPositionTopFrac", "allaSiteRules"], (cfg) => {
    const hostname = location.hostname;
    const siteRules = cfg.allaSiteRules || {};
    const siteRule = siteRules[hostname]; // 'always' | 'never' | undefined
    const globalMode = cfg.allaDisplayMode || DEFAULTS.displayMode;

    const effectiveMode = siteRule || globalMode;
    if (effectiveMode === "never") return;

    mountOrb(cfg.allaPositionTopFrac ?? DEFAULTS.positionTopFrac);
  });

  function mountOrb(topFrac) {
    const host = document.createElement("div");
    host.id = "alla-orb-host";
    host.style.cssText = [
      "all: initial",
      "position: fixed",
      "right: 18px",
      `top: ${Math.round(topFrac * window.innerHeight)}px`,
      "z-index: 2147483000", // high, but not the max possible — avoid arms-racing with page z-index hacks
      "cursor: grab",
    ].join(";");
    document.documentElement.appendChild(host);
    host.attachShadow({ mode: "open" });

    // The component (alla-orb.classic.js) executes in the page's MAIN
    // world once injected, so it has no access to chrome.runtime — hand it
    // everything it needs via the script tag's own data-* attributes,
    // which it reads off document.currentScript at the top of its own
    // execution (see the bottom of alla-orb.classic.js).
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("orb/alla-orb.classic.js");
    script.dataset.hostId = host.id;
    script.dataset.spriteUrl = chrome.runtime.getURL("orb/assets/orb-sprite.png");
    script.dataset.plainUrl = chrome.runtime.getURL("orb/assets/header_38.png");
    script.dataset.size = String(DEFAULTS.orbSize);
    script.dataset.label = "Open Agent Alla";
    document.documentElement.appendChild(script);
    script.remove(); // a classic src script still runs once fetched; keep the DOM tidy

    // The main-world script dispatches this on the host itself once the
    // <alla-orb> is mounted — events cross the isolated/main world
    // boundary fine even though object references don't.
    host.addEventListener("alla-orb-activate", onActivate);

    setupDrag(host, topFrac);
  }

  function onActivate() {
    chrome.runtime.sendMessage({ type: "alla:open-side-panel" });
  }

  function setupDrag(host, topFrac) {
    let dragging = false;
    let startY = 0;
    let startTop = 0;

    host.addEventListener("pointerdown", (e) => {
      dragging = true;
      startY = e.clientY;
      startTop = host.getBoundingClientRect().top;
      host.style.cursor = "grabbing";
      host.setPointerCapture(e.pointerId);
    });

    host.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const delta = e.clientY - startY;
      const newTop = Math.min(
        Math.max(8, startTop + delta),
        window.innerHeight - 8 - DEFAULTS.orbSize
      );
      host.style.top = `${newTop}px`;
    });

    const endDrag = (e) => {
      if (!dragging) return;
      dragging = false;
      host.style.cursor = "grab";
      const frac = host.getBoundingClientRect().top / window.innerHeight;
      chrome.storage.sync.set({ allaPositionTopFrac: frac });
    };
    host.addEventListener("pointerup", endDrag);
    host.addEventListener("pointercancel", endDrag);

    // Keep position sane across viewport resizes.
    window.addEventListener("resize", () => {
      const rect = host.getBoundingClientRect();
      const clampedTop = Math.min(rect.top, window.innerHeight - 8 - DEFAULTS.orbSize);
      host.style.top = `${Math.max(8, clampedTop)}px`;
    });
  }
})();
