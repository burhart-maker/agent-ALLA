/**
 * <alla-orb> — reusable Agent ALLA visual identity component.
 *
 * Implements the "lightweight" renderer decided on 11.09.2026
 * (agent-alla/browser-extension-orb-visual-audit.md, points 8/13/9):
 * a pre-rendered rotation SPRITE SHEET (24 frames, real icosphere geometry,
 * confirmed magenta palette, flat-shaded facets — see tools/generate_orb.py)
 * animated with a pure-CSS `steps()` background-position animation. No
 * WebGL/three.js at runtime. The full WebGL renderer stays reserved for the
 * marketing site / hero / large profile use (see audit doc) — this
 * component is for the browser extension's floating orb and side-panel
 * header, and for any other 16–160px "assistant" surface.
 *
 * Usage:
 *   <alla-orb size="48" state="idle" theme="auto" interactive
 *              label="Open Agent Alla"></alla-orb>
 *
 * Attributes:
 *   size          number (px) or one of: tiny(20) small(32) default(48) profile(80) brand(160)
 *   state         idle | hover | active | listening | processing | notification | error | offline
 *   theme         light | dark | auto (default: auto)
 *   interactive   presence = clickable/focusable button; absence = decorative (aria-hidden)
 *   label         accessible name when interactive (default: "Open Agent Alla")
 *   reduced-motion  auto | force-on | force-off (default: auto -> respects prefers-reduced-motion)
 *
 * Events:
 *   'alla-orb-activate'  — fired on click / Enter / Space when interactive
 *
 * Assets are resolved relative to this module unless overridden by setting
 * `AllaOrb.spriteUrl` / `AllaOrb.spriteMeta` before first use (the extension
 * sets these to its packaged asset URLs — see content-script/orb-mount.js).
 */

const SIZE_PRESETS = {
  tiny: 20,
  small: 32,
  default: 48,
  profile: 80,
  brand: 160,
};

const DEFAULT_FRAME_SIZE = 300;
const DEFAULT_FRAME_COUNT = 16; // real captured frames of the actual reference render, see assets/orb-sprite.json
const PLAIN_THRESHOLD_PX = 28; // below this, the wordmark reads as mush anyway — use the real plain-sphere crop instead

class AllaOrb extends HTMLElement {
  static spriteUrl = null; // set by host app to the packaged sprite PNG URL (real captured frames)
  static plainUrl = null;  // set by host app to the packaged plain-sphere PNG (real crop, no mark, no animation)
  static frameSize = DEFAULT_FRAME_SIZE;
  static frameCount = DEFAULT_FRAME_COUNT;

  static get observedAttributes() {
    return ["size", "state", "theme", "interactive", "label", "reduced-motion"];
  }

  constructor() {
    super();
    this._root = this.attachShadow({ mode: "open" });
    this._onKeydown = this._onKeydown.bind(this);
    this._onClick = this._onClick.bind(this);
  }

  connectedCallback() {
    this._render();
    this._observeVisibility();
  }

  disconnectedCallback() {
    if (this._io) this._io.disconnect();
    document.removeEventListener("visibilitychange", this._visHandler);
  }

  attributeChangedCallback() {
    if (this._root.firstChild) this._render();
  }

  _resolvedSize() {
    const raw = this.getAttribute("size") || "default";
    if (SIZE_PRESETS[raw]) return SIZE_PRESETS[raw];
    const n = parseInt(raw, 10);
    return Number.isFinite(n) && n > 0 ? n : SIZE_PRESETS.default;
  }

  _prefersReducedMotion() {
    const mode = this.getAttribute("reduced-motion") || "auto";
    if (mode === "force-on") return true;
    if (mode === "force-off") return false;
    return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  _render() {
    const size = this._resolvedSize();
    const state = this.getAttribute("state") || "idle";
    const theme = this.getAttribute("theme") || "auto";
    const interactive = this.hasAttribute("interactive");
    const label = this.getAttribute("label") || "Open Agent Alla";
    const reduced = this._prefersReducedMotion();

    // Below PLAIN_THRESHOLD_PX the "AGENT ALLA" mark baked into the real
    // captured frames is illegible anyway (exactly the reference's own
    // behavior — its 40/80px cards already reduce to a small mark, and its
    // 38px header icon drops the mark entirely) — at that size we use the
    // real plain-sphere crop (header_38.png) instead: a single static real
    // frame, no sprite, no animation. This is "just the ball" per spec,
    // not a redraw — same asset family, smallest real reference crop.
    const useTinyPlain = size < PLAIN_THRESHOLD_PX;
    const spriteUrl = AllaOrb.spriteUrl || "assets/orb-sprite.png";
    const plainUrl = AllaOrb.plainUrl || "assets/header_38.png";
    const frameCount = AllaOrb.frameCount;
    const animate = !useTinyPlain && !reduced;
    // Pixel-based sprite math (not the usual percentage trick): this Chromium
    // build visibly mis-renders an animated `background-position` percentage
    // against an oversized `background-size` percentage (verified in
    // packages/alla-orb/sprite_debug*.html — the percentage version squashes
    // into a lens/diamond shape under animation, the pixel version doesn't).
    // Pixel math sidesteps it and is the more common technique anyway.
    const totalWidthPx = frameCount * size;

    // Idle animation duration: the captured source is ~4.8s of real shimmer
    // movement (16 frames @ 280ms) looped, slowed further for "very slow,
    // elegant" idle per spec; processing/listening speed it back up.
    const baseDuration = 9;
    const duration = state === "processing" ? baseDuration * 0.35
      : state === "listening" ? baseDuration * 0.6
      : baseDuration;

    this._root.innerHTML = `
      <style>
        :host {
          display: inline-block;
          width: ${size}px;
          height: ${size}px;
          line-height: 0;
          --alla-glow: 0 0 0 rgba(216,0,134,0);
        }
        .orb {
          display: block;
          width: 100%;
          height: 100%;
          border-radius: 50%;
          background-image: url("${useTinyPlain ? plainUrl : spriteUrl}");
          background-repeat: no-repeat;
          background-size: ${useTinyPlain ? `${size}px ${size}px` : `${totalWidthPx}px ${size}px`};
          background-position: 0px 0px;
          box-shadow: var(--alla-glow);
          transition: box-shadow 200ms ease, transform 150ms ease, filter 200ms ease;
          transform: scale(1);
          will-change: background-position;
        }
        .orb.spin {
          animation: alla-spin ${duration}s steps(${frameCount}) infinite;
        }
        @keyframes alla-spin {
          from { background-position-x: 0px; }
          to   { background-position-x: -${totalWidthPx}px; }
        }
        button.orb-btn {
          all: unset;
          display: inline-block;
          width: ${size}px;
          height: ${size}px;
          border-radius: 50%;
          cursor: pointer;
        }
        button.orb-btn:focus-visible .orb {
          box-shadow: 0 0 0 3px rgba(216,0,134,0.55);
        }
        :host([data-state="hover"]) .orb,
        button.orb-btn:hover .orb {
          transform: scale(1.06);
        }
        :host([data-state="active"]) .orb {
          box-shadow: 0 0 0 4px rgba(216,0,134,0.35);
        }
        :host([data-state="notification"]) .orb {
          animation: alla-pulse-once 900ms ease-out 1;
        }
        @keyframes alla-pulse-once {
          0%   { transform: scale(1); }
          35%  { transform: scale(1.16); }
          70%  { transform: scale(0.97); }
          100% { transform: scale(1); }
        }
        :host([data-state="error"]) .orb,
        :host([data-state="offline"]) .orb {
          filter: grayscale(0.85) brightness(0.9);
        }
        :host([data-theme="dark"]) .orb {
          filter: brightness(1.05) saturate(1.05);
        }
        @media (prefers-reduced-motion: reduce) {
          .orb.spin { animation: none; }
        }
      </style>
      ${interactive
        ? `<button type="button" class="orb-btn" aria-label="${label}"><span class="orb ${animate ? "spin" : ""}"></span></button>`
        : `<span class="orb ${animate ? "spin" : ""}" role="img" aria-label="${label}" aria-hidden="${!interactive}"></span>`
      }
    `;

    this.dataset.state = state;
    this.dataset.theme = theme;

    if (interactive) {
      const btn = this._root.querySelector("button");
      btn.addEventListener("click", this._onClick);
      btn.addEventListener("keydown", this._onKeydown);
    }
  }

  _onClick(e) {
    this.dispatchEvent(new CustomEvent("alla-orb-activate", { bubbles: true, composed: true }));
  }

  _onKeydown(e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      this._onClick(e);
    }
  }

  _observeVisibility() {
    // Pause the CSS animation entirely when off-screen or the tab is hidden —
    // same pattern confirmed in Agent-ALLA-Standalone.html (IntersectionObserver
    // + prefers-reduced-motion), see audit doc point 6/7.
    const pause = (shouldPause) => {
      const orb = this._root.querySelector(".orb");
      if (orb) orb.style.animationPlayState = shouldPause ? "paused" : "running";
    };
    if ("IntersectionObserver" in window) {
      this._io = new IntersectionObserver((entries) => {
        for (const entry of entries) pause(!entry.isIntersecting);
      }, { threshold: 0.01 });
      this._io.observe(this);
    }
    this._visHandler = () => pause(document.hidden);
    document.addEventListener("visibilitychange", this._visHandler);
  }
}

if (!customElements.get("alla-orb")) {
  customElements.define("alla-orb", AllaOrb);
}


// --- Content-script bootstrap (main-world) -------------------------------
// Runs once, right after this classic script's own top-level code (the
// class declaration + customElements.define() above) has executed. Reads
// its config from this very <script> tag's data-* attributes — set by
// content-script/orb-host.js, which has chrome.runtime access that this
// main-world script does not — and mounts <alla-orb> into the host's
// (open) shadow root.
(function bootstrapAllaOrb() {
  const scriptEl = document.currentScript;
  if (!scriptEl || !scriptEl.dataset.hostId) return; // loaded standalone (e.g. side panel/options import it as a module instead), nothing to bootstrap

  const host = document.getElementById(scriptEl.dataset.hostId);
  if (!host || !host.shadowRoot) return;

  AllaOrb.spriteUrl = scriptEl.dataset.spriteUrl || AllaOrb.spriteUrl;
  AllaOrb.plainUrl = scriptEl.dataset.plainUrl || AllaOrb.plainUrl;

  const orb = document.createElement("alla-orb");
  orb.setAttribute("size", scriptEl.dataset.size || "48");
  orb.setAttribute("state", "idle");
  orb.setAttribute("interactive", "");
  orb.setAttribute("label", scriptEl.dataset.label || "Open Agent Alla");
  host.shadowRoot.appendChild(orb);
})();
